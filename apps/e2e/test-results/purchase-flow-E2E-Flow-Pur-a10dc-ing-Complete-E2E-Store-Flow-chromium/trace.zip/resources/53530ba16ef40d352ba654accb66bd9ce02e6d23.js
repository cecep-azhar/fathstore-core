(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_a8d81c62._.js",
  "static/chunks/40ccb_next_dist_compiled_react-dom_253ff436._.js",
  "static/chunks/40ccb_next_dist_compiled_react-server-dom-turbopack_61dc814d._.js",
  "static/chunks/40ccb_next_dist_compiled_next-devtools_index_272f3077.js",
  "static/chunks/40ccb_next_dist_compiled_f8341a83._.js",
  "static/chunks/40ccb_next_dist_client_21cbb6fe._.js",
  "static/chunks/40ccb_next_dist_f6b65a9e._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
