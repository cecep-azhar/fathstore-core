(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_94872677._.js",
  "static/chunks/apps_member_app_globals_e88e405b.css"
],
    source: "dynamic"
});
